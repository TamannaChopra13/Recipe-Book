# RecipeBook

## Recreated Recipe App created with Firestore to MERN app created with react-redux

### Version 4.0.0 RecipeBook App

To start the project after downloading, from root directory, in terminal run:

1. npm install
2. cd frontend
3. npm install
4. cd ../
5. npm run dev

This will install all dependencies for frontend and backend and spin both frontend and backend.
